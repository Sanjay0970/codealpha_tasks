This project predicts whether a person is creditworthy based on historical financial and demographic data.
It uses Machine Learning models in Python to analyze credit scoring datasets and classify applicants into good or bad credit risk.
